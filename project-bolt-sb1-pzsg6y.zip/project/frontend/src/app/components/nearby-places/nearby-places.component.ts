import { Component, OnInit, OnDestroy } from '@angular/core';
import { PlacesService } from '../../services/places.service';
import { LocationService } from '../../services/location.service';
import { Hospital, PoliceStation } from '../../models/location.model';
import { Subscription } from 'rxjs';
import { debounceTime, filter } from 'rxjs/operators';

@Component({
  selector: 'app-nearby-places',
  templateUrl: './nearby-places.component.html',
  styleUrls: ['./nearby-places.component.scss']
})
export class NearbyPlacesComponent implements OnInit, OnDestroy {
  hospitals: Hospital[] = [];
  policeStations: PoliceStation[] = [];
  loading = false;
  error: string | null = null;
  private locationSubscription?: Subscription;

  constructor(
    private placesService: PlacesService,
    private locationService: LocationService
  ) {}

  ngOnInit() {
    // Subscribe to location updates
    this.locationSubscription = this.locationService.location$
      .pipe(
        filter(location => location !== null),
        debounceTime(1000) // Prevent too frequent updates
      )
      .subscribe(location => {
        if (location) {
          this.updateLocationAndLoadPlaces(location);
        }
      });
  }

  ngOnDestroy() {
    this.locationSubscription?.unsubscribe();
  }

  private updateLocationAndLoadPlaces(location: { latitude: number; longitude: number }) {
    this.loading = true;
    this.error = null;

    this.placesService.updateLocation(location).subscribe({
      next: () => this.loadNearbyPlaces(),
      error: (error) => {
        this.error = 'Error updating location';
        this.loading = false;
      }
    });
  }

  private loadNearbyPlaces() {
    Promise.all([
      this.placesService.getNearbyHospitals().toPromise(),
      this.placesService.getNearbyPoliceStations().toPromise()
    ]).then(([hospitals, policeStations]) => {
      this.hospitals = hospitals || [];
      this.policeStations = policeStations || [];
      this.loading = false;
    }).catch(error => {
      this.error = 'Error loading nearby places';
      this.loading = false;
    });
  }

  refreshLocation() {
    this.locationService.startTracking();
  }
}