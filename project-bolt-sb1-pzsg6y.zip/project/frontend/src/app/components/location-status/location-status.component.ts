import { Component, OnInit, OnDestroy } from '@angular/core';
import { LocationService, Coordinates } from '../../services/location.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-location-status',
  templateUrl: './location-status.component.html'
})
export class LocationStatusComponent implements OnInit, OnDestroy {
  currentLocation: Coordinates | null = null;
  locationAge: number = 0;
  private locationSubscription?: Subscription;
  private updateInterval?: number;

  constructor(private locationService: LocationService) {}

  ngOnInit() {
    this.locationSubscription = this.locationService.location$.subscribe(
      location => {
        this.currentLocation = location;
        this.updateLocationAge();
      }
    );

    // Update location age every minute
    this.updateInterval = window.setInterval(() => {
      this.updateLocationAge();
    }, 60000);
  }

  ngOnDestroy() {
    this.locationSubscription?.unsubscribe();
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
    }
  }

  private updateLocationAge() {
    if (this.currentLocation?.timestamp) {
      this.locationAge = Math.floor((Date.now() - this.currentLocation.timestamp) / 1000 / 60);
    }
  }

  getAccuracyText(): string {
    if (!this.currentLocation?.accuracy) return 'Unknown accuracy';
    if (this.currentLocation.accuracy < 100) return 'High accuracy';
    if (this.currentLocation.accuracy < 1000) return 'Medium accuracy';
    return 'Low accuracy';
  }
}