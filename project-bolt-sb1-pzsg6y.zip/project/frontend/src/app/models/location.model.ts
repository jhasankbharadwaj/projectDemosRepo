export interface Location {
    latitude: number;
    longitude: number;
}

export interface Hospital {
    id: number;
    placeId: string;
    name: string;
    address: string;
    latitude: number;
    longitude: number;
    distance: number;
    phoneNumber: string;
    rating: number;
    lastUpdated: Date;
}

export interface PoliceStation {
    id: number;
    placeId: string;
    name: string;
    address: string;
    latitude: number;
    longitude: number;
    distance: number;
    phoneNumber: string;
    rating: number;
    lastUpdated: Date;
}