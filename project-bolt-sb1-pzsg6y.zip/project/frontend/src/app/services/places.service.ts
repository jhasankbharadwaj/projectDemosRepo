import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Location, Hospital, PoliceStation } from '../models/location.model';

@Injectable({
    providedIn: 'root'
})
export class PlacesService {
    private apiUrl = 'https://localhost:7001/api/places'; // Update with your API URL

    constructor(private http: HttpClient) { }

    updateLocation(location: Location): Observable<void> {
        return this.http.post<void>(`${this.apiUrl}/update-location`, location);
    }

    getNearbyHospitals(): Observable<Hospital[]> {
        return this.http.get<Hospital[]>(`${this.apiUrl}/hospitals`);
    }

    getNearbyPoliceStations(): Observable<PoliceStation[]> {
        return this.http.get<PoliceStation[]>(`${this.apiUrl}/police-stations`);
    }
}