import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, from, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';

export interface Coordinates {
  latitude: number;
  longitude: number;
  accuracy?: number;
  timestamp?: number;
}

@Injectable({
  providedIn: 'root'
})
export class LocationService {
  private readonly LOCATION_UPDATE_INTERVAL = 5 * 60 * 1000; // 5 minutes
  private readonly LOCATION_CACHE_KEY = 'last_known_location';
  private locationSubject = new BehaviorSubject<Coordinates | null>(null);
  private watchId: number | null = null;

  constructor(private http: HttpClient) {
    this.initializeLocation();
  }

  private async initializeLocation() {
    // Try to load cached location
    const cachedLocation = this.getCachedLocation();
    if (cachedLocation) {
      this.locationSubject.next(cachedLocation);
    }

    // Start tracking
    await this.startTracking();
  }

  get location$(): Observable<Coordinates | null> {
    return this.locationSubject.asObservable();
  }

  async startTracking(): Promise<void> {
    if (this.watchId !== null) {
      return;
    }

    if ('geolocation' in navigator) {
      // High accuracy tracking
      this.watchId = navigator.geolocation.watchPosition(
        (position) => this.handleNewPosition(position),
        async (error) => {
          console.warn('GPS error:', error);
          await this.fallbackToIPLocation();
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: this.LOCATION_UPDATE_INTERVAL
        }
      );
    } else {
      await this.fallbackToIPLocation();
    }
  }

  stopTracking(): void {
    if (this.watchId !== null) {
      navigator.geolocation.clearWatch(this.watchId);
      this.watchId = null;
    }
  }

  private async fallbackToIPLocation(): Promise<void> {
    try {
      const response = await this.http.get<any>('https://ipapi.co/json/').toPromise();
      const location: Coordinates = {
        latitude: response.latitude,
        longitude: response.longitude,
        accuracy: 5000, // IP geolocation is less accurate
        timestamp: Date.now()
      };
      this.handleNewLocation(location);
    } catch (error) {
      console.error('IP geolocation failed:', error);
    }
  }

  private handleNewPosition(position: GeolocationPosition): void {
    const location: Coordinates = {
      latitude: position.coords.latitude,
      longitude: position.coords.longitude,
      accuracy: position.coords.accuracy,
      timestamp: position.timestamp
    };
    this.handleNewLocation(location);
  }

  private handleNewLocation(location: Coordinates): void {
    this.locationSubject.next(location);
    this.cacheLocation(location);
  }

  private getCachedLocation(): Coordinates | null {
    const cached = localStorage.getItem(this.LOCATION_CACHE_KEY);
    if (!cached) return null;

    try {
      const location = JSON.parse(cached);
      const timestamp = location.timestamp || 0;
      const age = Date.now() - timestamp;

      // Return cached location if it's less than 5 minutes old
      return age < this.LOCATION_UPDATE_INTERVAL ? location : null;
    } catch {
      return null;
    }
  }

  private cacheLocation(location: Coordinates): void {
    localStorage.setItem(this.LOCATION_CACHE_KEY, JSON.stringify(location));
  }
}