using Microsoft.EntityFrameworkCore;

public class PlacesDbContext : DbContext
{
    public PlacesDbContext(DbContextOptions<PlacesDbContext> options) : base(options)
    {
    }

    public DbSet<Hospital> Hospitals { get; set; }
    public DbSet<PoliceStation> PoliceStations { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Hospital>()
            .HasIndex(h => h.PlaceId)
            .IsUnique();

        modelBuilder.Entity<PoliceStation>()
            .HasIndex(p => p.PlaceId)
            .IsUnique();
    }
}