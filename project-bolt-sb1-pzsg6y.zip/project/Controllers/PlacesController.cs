using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/[controller]")]
public class PlacesController : ControllerBase
{
    private readonly PlacesDbContext _context;
    private readonly PlacesService _placesService;

    public PlacesController(PlacesDbContext context, PlacesService placesService)
    {
        _context = context;
        _placesService = placesService;
    }

    [HttpGet("hospitals")]
    public async Task<ActionResult<IEnumerable<Hospital>>> GetNearbyHospitals()
    {
        return await _context.Hospitals
            .OrderBy(h => h.Distance)
            .Take(5)
            .ToListAsync();
    }

    [HttpGet("police-stations")]
    public async Task<ActionResult<IEnumerable<PoliceStation>>> GetNearbyPoliceStations()
    {
        return await _context.PoliceStations
            .OrderBy(p => p.Distance)
            .Take(5)
            .ToListAsync();
    }

    [HttpPost("update-location")]
    public async Task<IActionResult> UpdateLocation([FromBody] LocationUpdate location)
    {
        await _placesService.UpdatePlacesForLocation(location.Latitude, location.Longitude);
        return Ok();
    }
}