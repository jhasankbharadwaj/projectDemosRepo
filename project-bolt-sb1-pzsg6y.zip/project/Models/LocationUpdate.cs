public class LocationUpdate
{
    public double Latitude { get; set; }
    public double Longitude { get; set; }
}