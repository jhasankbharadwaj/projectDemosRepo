using Google.Maps;
using Google.Maps.Places;
using Microsoft.EntityFrameworkCore;

public class PlacesService : BackgroundService
{
    private readonly ILogger<PlacesService> _logger;
    private readonly IServiceProvider _serviceProvider;
    private readonly string _apiKey;
    private readonly TimeSpan _updateInterval = TimeSpan.FromMinutes(30);
    private LatLng _currentLocation = new LatLng(37.7749, -122.4194); // Default to San Francisco

    public PlacesService(
        ILogger<PlacesService> logger,
        IServiceProvider serviceProvider,
        IConfiguration configuration)
    {
        _logger = logger;
        _serviceProvider = serviceProvider;
        _apiKey = configuration["GooglePlaces:ApiKey"];
        GoogleSigned.AssignAllServices(new GoogleSigned(_apiKey));
    }

    public async Task UpdatePlacesForLocation(double latitude, double longitude)
    {
        _currentLocation = new LatLng(latitude, longitude);
        await UpdateNearbyPlaces();
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await UpdateNearbyPlaces();
                await Task.Delay(_updateInterval, stoppingToken);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating nearby places");
                await Task.Delay(TimeSpan.FromMinutes(1), stoppingToken);
            }
        }
    }

    private async Task UpdateNearbyPlaces()
    {
        using var scope = _serviceProvider.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<PlacesDbContext>();
        
        await UpdateHospitals(dbContext, _currentLocation);
        await UpdatePoliceStations(dbContext, _currentLocation);
    }

    // Rest of the service implementation remains the same
}